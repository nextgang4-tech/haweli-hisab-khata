# APK Build & Installation Guide (GitHub Actions & Android Studio)

## विकल्प 1: बिना कंप्यूटर/लैपटॉप के सीधे GitHub Actions से APK बनाएं (Recommended)
1. GitHub पर एक नया Repository बनाएं और इस ज़िप फाइल (`haweli_android_project.zip`) की सभी फाइलें उसमें अपलोड/Push करें।
2. रिपॉजिटरी में ऊपर **Actions** टैब पर क्लिक करें।
3. **HAWELI Android APK Build (Debug & Release)** वर्कफ़्लो अपने-आप चलेगा और लगभग 2–3 मिनट में पूरा हो जाएगा।
4. वर्कफ़्लो खुलने पर नीचे **Artifacts** सेक्शन से **`HAWELI-Hisab-Debug-APK`** या **`HAWELI-Hisab-Release-APK`** डाउनलोड करें।
5. अपने मोबाइल में APK फाइल खोलें, *"Install from Unknown Sources"* की अनुमति दें और इंस्टॉल करें।

## विकल्प 2: Android Studio से APK बनाएं
1. Android Studio (Hedgehog या नया वर्शन) खोलें और इस प्रोजेक्ट फोल्डर को **Open** करें।
2. Gradle Sync पूरा होने के बाद ऊपर मेनू से **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** पर क्लिक करें।
3. `app/build/outputs/apk/debug/app-debug.apk` फाइल तैयार हो जाएगी जिसे आप WhatsApp या केबल से किसी भी मोबाइल में भेजकर इंस्टॉल कर सकते हैं।
