# HAWELI – संपूर्ण व्यावसायिक हिसाब-किताब Android App (`com.haweli.hisab`)

**HAWELI** एक आधुनिक, तेज़ और 100% सटीक (Integer Paise / `BigDecimal` आधारित) हिंदी व्यावसायिक हिसाब-किताब Android एप्लिकेशन है। यह ऐप कई मोबाइलों पर **Firebase Firestore Real-Time Sync** और **Offline Persistence** के साथ काम करती है।

---

## 1. मुख्य विशेषताएं (Modules Included)

1. **होम पेज डैशबोर्ड (Dashboard)**
   - **पहला कार्ड – देना (Dena)**: कुल देना, अब तक कुल भुगतान, आज का भुगतान, पुरानी बाकी, और वर्तमान बाकी देना।
   - **दूसरा कार्ड – आना (Aana)**: कुल आना, अब तक प्राप्त भुगतान, आज आया पैसा, पुरानी बाकी, और वर्तमान बाकी आना।
   - **सख्त नियम**: `आना` और `देना` कभी भी आपस में अपने-आप Adjust नहीं होते और हर पार्टी का खाता पूरी तरह अलग (Isolated) रहता है।
2. **देना सेक्शन (Dena – City Wise)**
   - शहर जोड़ने, एडिट करने और डिलीट करने की सुविधा (उदाहरण: बारामती, भूम, धाराशिव)।
   - बड़े जानवरों का हिसाब (`कुल वजन KG × प्रति KG रेट = कुल रकम`) और Veal माल का हिसाब (`वजन × रेट = रकम`)।
   - तारीख के अनुसार अलग-अलग भुगतान जोड़ने, एडिट और डिलीट करने की सुविधा।
3. **आना सेक्शन (Aana – Vehicle & City Wise)**
   - पार्टी का नाम, शहर, मोबाइल नंबर, **गाड़ी नंबर** और गाड़ी भेजने की तारीख।
   - बड़े जानवर + Veal माल + अन्य खर्च/एडजस्टमेंट से कुल बिल की गणना और प्राप्त भुगतान का पूरा इतिहास।
4. **ऑफिस सेक्शन – APSAR BHAI**
   - **पैसे दिए** और **पैसे लिए** का पूरा हिसाब, तीन मुख्य डैशबोर्ड कार्ड (`कुल दिए`, `कुल लिए`, `वर्तमान बाकी = कुल दिए - कुल लिए`), और अधिक लिए गए पैसों की अलग चेतावनी।
5. **महीने का हिसाब (Monthly & Custom Date Range Report)**
   - किसी भी दो तारीखों (जैसे `18/11/2026 से 18/12/2026`) के बीच कटे/भेजे गए बड़े जानवर, कुल वजन, Veal माल, देना/आना बिल, भुगतान, पुराना बकाया अलग से और महीने के अंत का सटीक बैलेंस।
   - PDF, प्रिंट और Excel (CSV UTF-8) में डाउनलोड करने की सुविधा।
6. **Firebase Lock System & Admin Security**
   - `Settings` में Firebase Project ID, API Key और App ID डालकर **Connect & Lock** करने की सुविधा।
   - एक बार Lock होने के बाद सामान्य उपयोगकर्ता Configuration को देख या बदल नहीं सकता।
   - Admin Credentials को Source Code में Hardcode नहीं किया गया है; पहली बार सेटअप पर SHA-256 Salted Hash + Firebase Auth और `firestore.rules` से सुरक्षा लागू होती है।

---

## 2. GitHub Actions से Installable APK कैसे प्राप्त करें

1. इस पूरे प्रोजेक्ट फोल्डर को अपने GitHub Repository में Push करें।
2. GitHub पर **Actions** टैब में जाएं — `.github/workflows/build-apk.yml` अपने-आप चलेगा।
3. Build पूरा होने पर **Artifacts** सेक्शन से **`HAWELI-Hisab-Debug-APK`** या **`HAWELI-Hisab-Release-APK`** डाउनलोड करें और अपने सभी मोबाइलों में इंस्टॉल करें।

---

## 3. Firebase Setup और Real-Time Multi-Mobile Sync गाइड

1. [Firebase Console](https://console.firebase.google.com/) पर जाकर नया प्रोजेक्ट बनाएं (जैसे `haweli-hisab-cloud`)।
2. **Build -> Firestore Database** में जाकर डेटाबेस बनाएं और इस रिपॉजिटरी की `firestore.rules` फाइल के नियम **Rules** टैब में पेस्ट करके **Publish** करें।
3. **Build -> Authentication** में जाकर **Email/Password** और **Anonymous/Custom Auth** चालू करें।
4. **Project Settings** से अपना `Project ID`, `Web API Key`, और `App ID` कॉपी करें।
5. HAWELI ऐप खोलें -> **सेटिंग (Settings)** में जाएं -> पहले **Admin Login** करें (प्रथम बार एडमिन अकाउंट सेटअप करें: Username `haweli`, Password `Haweli123`) -> फिर Firebase विवरण डालकर **Connect & Lock Configuration** दबाएं।
6. यही APK अपने दूसरे मोबाइलों पर भेजें और वही Firebase विवरण डालकर Lock कर दें — अब एक मोबाइल पर की गई हर एंट्री दूसरे मोबाइल पर तुरंत Real-Time में दिखाई देगी!
