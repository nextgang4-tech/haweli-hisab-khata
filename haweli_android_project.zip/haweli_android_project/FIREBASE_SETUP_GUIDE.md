# Firebase Firestore & Real-Time Multi-Mobile Setup Guide (HAWELI)

1. **Firebase Project बनाएं**:
   - https://console.firebase.google.com/ पर जाएं और **Add project** पर क्लिक करके `haweli-hisab` नाम से प्रोजेक्ट बनाएं।
2. **Firestore Database चालू करें**:
   - बाएँ मेनू में **Build -> Firestore Database** चुनें और **Create database** पर क्लिक करें।
   - लोकेशन `asia-south1 (Mumbai)` चुनें।
3. **Firestore Security Rules लगाएं**:
   - **Rules** टैब में जाकर इस प्रोजेक्ट की `firestore.rules` फाइल का पूरा कोड पेस्ट करें और **Publish** दबाएं।
4. **Authentication चालू करें**:
   - **Build -> Authentication -> Sign-in method** में जाकर **Email/Password** चालू करें।
5. **ऐप में Configuration डालें और Lock करें**:
   - HAWELI ऐप में **सेटिंग & Admin** टैब खोलें।
   - अपना `Firebase Project ID`, `Firebase API Key`, और `Firebase App ID` डालकर **Firebase Connect & Lock Configuration** बटन दबाएं।
   - Lock होने के बाद सामान्य यूज़र इसे देख या बदल नहीं पाएंगे, और सभी जुड़े मोबाइलों पर Real-Time Sync तुरंत चालू हो जाएगा।
