package com.haweli.hisab.model

import com.haweli.hisab.util.CurrencyUtils

/**
 * Ledger Type: DENA (देना - Suppliers/Purchases) vs AANA (आना - Buyers/Dispatches).
 * Never auto-adjusted against each other.
 */
enum class LedgerType {
    DENA, AANA
}

data class CityRecord(
    val id: String = "",
    val name: String = "", // e.g., बारामती, भूम, धाराशिव
    val section: String = "BOTH", // DENA, AANA, or BOTH
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "admin"
)

data class PartyRecord(
    val id: String = "",
    val name: String = "",
    val mobile: String = "",
    val cityId: String = "",
    val cityName: String = "",
    val address: String = "",
    val type: String = LedgerType.DENA.name, // Strictly DENA or AANA
    val openingBalancePaise: Long = 0L, // शुरुआती पुरानी बाकी (in Paise)
    val entryDate: String = CurrencyUtils.formatDateDdMmYyyy(System.currentTimeMillis()),
    val entryTimestamp: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "admin"
)

/**
 * Represents a Bill / Maal Entry for either DENA (Purchase) or AANA (Vehicle Dispatch).
 */
data class BillTransaction(
    val id: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val cityId: String = "",
    val cityName: String = "",
    val type: String = LedgerType.DENA.name, // DENA or AANA
    val date: String = CurrencyUtils.formatDateDdMmYyyy(System.currentTimeMillis()), // DD/MM/YYYY
    val timestamp: Long = System.currentTimeMillis(),
    val vehicleNumber: String = "", // गाड़ी नंबर (Used in AANA section)
    // बड़े जानवर का विवरण
    val bigAnimalCount: Int = 0,
    val bigAnimalWeightGrams: Long = 0L, // 1 KG = 1000 Grams
    val bigAnimalRatePaise: Long = 0L,
    val bigAnimalTotalPaise: Long = 0L, // Auto-calculated: Weight * Rate
    // Veal माल का विवरण
    val vealWeightGrams: Long = 0L,
    val vealRatePaise: Long = 0L,
    val vealTotalPaise: Long = 0L, // Auto-calculated: Weight * Rate
    // अन्य खर्च या एडजस्टमेंट (AANA optional)
    val otherExpensePaise: Long = 0L,
    // कुल बिल रकम (Big Animal + Veal + Other Expense)
    val totalBillPaise: Long = 0L,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "admin"
)

/**
 * Represents a Payment Entry (भुगतान दिए in DENA, or प्राप्त भुगतान in AANA).
 */
data class PaymentTransaction(
    val id: String = "",
    val partyId: String = "",
    val partyName: String = "",
    val cityId: String = "",
    val cityName: String = "",
    val type: String = LedgerType.DENA.name, // DENA (Paid out) or AANA (Received)
    val date: String = CurrencyUtils.formatDateDdMmYyyy(System.currentTimeMillis()),
    val timestamp: Long = System.currentTimeMillis(),
    val amountPaise: Long = 0L,
    val paymentMode: String = "नकद (Cash)", // नकद, UPI, बैंक ट्रांसफर, चेक
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "admin"
)

/**
 * Office Section – APSAR BHAI Transaction
 * पैसे दिए (GIVEN) and पैसे लिए (TAKEN)
 */
data class OfficeApsarTransaction(
    val id: String = "",
    val direction: String = "GIVEN", // GIVEN (पैसे दिए) or TAKEN (पैसे लिए)
    val personName: String = "",
    val date: String = CurrencyUtils.formatDateDdMmYyyy(System.currentTimeMillis()),
    val timestamp: Long = System.currentTimeMillis(),
    val amountPaise: Long = 0L,
    val reason: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdBy: String = "admin"
)

/**
 * Audit Log Record – किसने कौन सी एंट्री कब जोड़ी/बदली/हटाई
 */
data class AuditLogEntry(
    val id: String = "",
    val action: String = "", // CREATE, UPDATE, DELETE, CONFIG_LOCK, LOGIN
    val module: String = "", // DENA, AANA, OFFICE_APSAR, CITY, PARTY, SETTINGS
    val summaryHindi: String = "",
    val performedBy: String = "",
    val deviceName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val dateFormatted: String = CurrencyUtils.formatDateDdMmYyyy(System.currentTimeMillis())
)

/**
 * Device / Mobile User Access Control Record managed by Admin
 */
data class AuthorizedMobileUser(
    val id: String = "",
    val username: String = "",
    val displayName: String = "",
    val role: String = "STAFF", // ADMIN or STAFF
    val canEdit: Boolean = true,
    val canDelete: Boolean = false,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Computed Summary for any single Party (Strictly isolated per party)
 */
data class PartyComputedSummary(
    val party: PartyRecord,
    val totalBigAnimals: Int,
    val totalBigWeightGrams: Long,
    val totalBigAmountPaise: Long,
    val totalVealWeightGrams: Long,
    val totalVealAmountPaise: Long,
    val totalOtherExpensePaise: Long,
    val newBillsTotalPaise: Long,
    val grandTotalPayableOrReceivablePaise: Long, // पुरानी बाकी + नए बिल
    val totalPaymentsPaise: Long,
    val todayPaymentsPaise: Long,
    val remainingBalancePaise: Long // कुल (देना/आना) - कुल भुगतान = बाकी
)
