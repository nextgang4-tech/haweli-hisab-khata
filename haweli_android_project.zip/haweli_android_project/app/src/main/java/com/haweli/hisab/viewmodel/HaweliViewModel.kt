package com.haweli.hisab.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.haweli.hisab.data.FirebaseConfigManager
import com.haweli.hisab.data.HaweliRepository
import com.haweli.hisab.model.*
import com.haweli.hisab.util.CurrencyUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DashboardCardSummary(
    val totalPayableOrReceivablePaise: Long = 0L, // कुल देना / कुल आना
    val totalPaidOrReceivedPaise: Long = 0L,      // कुल भुगतान / कुल प्राप्त
    val todayPaidOrReceivedPaise: Long = 0L,      // आज का भुगतान / आज आया पैसा
    val oldOpeningBalancePaise: Long = 0L,        // पुरानी बाकी
    val currentRemainingPaise: Long = 0L          // वर्तमान बाकी
)

data class ApsarBhaiDashboardSummary(
    val totalGivenPaise: Long = 0L, // कुल दिए हुए पैसे
    val totalTakenPaise: Long = 0L, // कुल लिए हुए पैसे
    val netBalancePaise: Long = 0L, // कुल दिए – कुल लिए = नेट बैलेंस
    val isExcessTaken: Boolean = false // यदि पैसे ज्यादा लिए गए हों
)

data class MonthlyReportSummary(
    val fromDate: String,
    val toDate: String,
    val bigAnimalCount: Int,
    val bigAnimalWeightGrams: Long,
    val bigAnimalTotalPaise: Long,
    val vealWeightGrams: Long,
    val vealTotalPaise: Long,
    val combinedWeightGrams: Long,
    val combinedMaalPaise: Long,
    val periodDenaBillsPaise: Long,
    val periodDenaPaymentsPaise: Long,
    val periodAanaBillsPaise: Long,
    val periodAanaPaymentsPaise: Long,
    val openingDenaBeforePeriodPaise: Long,
    val openingAanaBeforePeriodPaise: Long,
    val closingDenaAtEndPaise: Long,
    val closingAanaAtEndPaise: Long,
    val apsarGivenInPeriodPaise: Long,
    val apsarTakenInPeriodPaise: Long
)

class HaweliViewModel(application: Application) : AndroidViewModel(application) {

    val repository = HaweliRepository(application.applicationContext)

    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _currentUsername = MutableStateFlow("staff")
    val currentUsername: StateFlow<String> = _currentUsername.asStateFlow()

    fun loginAsAdmin(username: String, passwordPlain: String): Boolean {
        val ctx = getApplication<Application>().applicationContext
        if (!FirebaseConfigManager.isAdminProvisioned(ctx)) {
            // First-time Admin provisioning on device
            FirebaseConfigManager.provisionAdminAccount(ctx, username, passwordPlain)
            _isAdminLoggedIn.value = true
            _currentUsername.value = username.trim()
            return true
        }
        val verified = FirebaseConfigManager.verifyAdminCredentials(ctx, username, passwordPlain)
        if (verified) {
            _isAdminLoggedIn.value = true
            _currentUsername.value = username.trim()
        }
        return verified
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
        _currentUsername.value = "staff"
    }

    /**
     * Computes exact summary for a single Party using Integer Paise.
     * Strictly isolates each party's bills and payments.
     */
    fun computePartySummary(party: PartyRecord): PartyComputedSummary {
        val partyBills = repository.bills.value.filter { it.partyId == party.id && it.type == party.type }
        val partyPayments = repository.payments.value.filter { it.partyId == party.id && it.type == party.type }
        val todayStr = CurrencyUtils.formatDateDdMmYyyy(System.currentTimeMillis())

        val totalBigAnimals = partyBills.sumOf { it.bigAnimalCount }
        val totalBigWeightGrams = partyBills.sumOf { it.bigAnimalWeightGrams }
        val totalBigAmountPaise = partyBills.sumOf { it.bigAnimalTotalPaise }
        val totalVealWeightGrams = partyBills.sumOf { it.vealWeightGrams }
        val totalVealAmountPaise = partyBills.sumOf { it.vealTotalPaise }
        val totalOtherExpensePaise = partyBills.sumOf { it.otherExpensePaise }
        val newBillsTotalPaise = partyBills.sumOf { it.totalBillPaise }

        // कुल देना/आना = पुरानी बाकी + बड़े जानवरों की रकम + Veal माल की रकम (+ अन्य खर्च)
        val grandTotal = party.openingBalancePaise + newBillsTotalPaise
        val totalPaid = partyPayments.sumOf { it.amountPaise }
        val todayPaid = partyPayments.filter { it.date == todayStr }.sumOf { it.amountPaise }

        // बाकी रकम = कुल (देना/आना) – कुल भुगतान
        val remaining = grandTotal - totalPaid

        return PartyComputedSummary(
            party = party,
            totalBigAnimals = totalBigAnimals,
            totalBigWeightGrams = totalBigWeightGrams,
            totalBigAmountPaise = totalBigAmountPaise,
            totalVealWeightGrams = totalVealWeightGrams,
            totalVealAmountPaise = totalVealAmountPaise,
            totalOtherExpensePaise = totalOtherExpensePaise,
            newBillsTotalPaise = newBillsTotalPaise,
            grandTotalPayableOrReceivablePaise = grandTotal,
            totalPaymentsPaise = totalPaid,
            todayPaymentsPaise = todayPaid,
            remainingBalancePaise = remaining
        )
    }

    /**
     * Computes Dashboard Card Summary for either DENA or AANA across all parties of that type.
     * DENA and AANA are never mixed or auto-adjusted.
     */
    fun computeDashboardSummary(type: LedgerType): DashboardCardSummary {
        val matchingParties = repository.parties.value.filter { it.type == type.name }
        val summaries = matchingParties.map { computePartySummary(it) }

        val oldOpening = summaries.sumOf { it.party.openingBalancePaise }
        val grandTotal = summaries.sumOf { it.grandTotalPayableOrReceivablePaise }
        val totalPaid = summaries.sumOf { it.totalPaymentsPaise }
        val todayPaid = summaries.sumOf { it.todayPaymentsPaise }
        val remaining = grandTotal - totalPaid

        return DashboardCardSummary(
            totalPayableOrReceivablePaise = grandTotal,
            totalPaidOrReceivedPaise = totalPaid,
            todayPaidOrReceivedPaise = todayPaid,
            oldOpeningBalancePaise = oldOpening,
            currentRemainingPaise = remaining
        )
    }

    /**
     * Computes Office – APSAR BHAI Dashboard Summary
     * नेट बैलेंस नियम: कुल दिए – कुल लिए = नेट बैलेंस
     */
    fun computeApsarBhaiSummary(): ApsarBhaiDashboardSummary {
        val txs = repository.officeTransactions.value
        val given = txs.filter { it.direction == "GIVEN" }.sumOf { it.amountPaise }
        val taken = txs.filter { it.direction == "TAKEN" }.sumOf { it.amountPaise }
        val net = given - taken
        return ApsarBhaiDashboardSummary(
            totalGivenPaise = given,
            totalTakenPaise = taken,
            netBalancePaise = net,
            isExcessTaken = net < 0L
        )
    }

    /**
     * Computes Monthly / Custom Date Range Report strictly filtering entries inside [fromTs, toTs]
     * while showing prior opening balances separately and end-of-period total balance accurately.
     */
    fun computeDateRangeReport(fromDateStr: String, toDateStr: String): MonthlyReportSummary {
        val fromTs = CurrencyUtils.parseDdMmYyyy(fromDateStr)
        val toTs = CurrencyUtils.parseDdMmYyyy(toDateStr) + 86_399_000L // End of day

        val allParties = repository.parties.value
        val allBills = repository.bills.value
        val allPayments = repository.payments.value
        val allOffice = repository.officeTransactions.value

        val billsInPeriod = allBills.filter { it.timestamp in fromTs..toTs }
        val paymentsInPeriod = allPayments.filter { it.timestamp in fromTs..toTs }

        val bigAnimals = billsInPeriod.sumOf { it.bigAnimalCount }
        val bigWeight = billsInPeriod.sumOf { it.bigAnimalWeightGrams }
        val bigTotal = billsInPeriod.sumOf { it.bigAnimalTotalPaise }
        val vealWeight = billsInPeriod.sumOf { it.vealWeightGrams }
        val vealTotal = billsInPeriod.sumOf { it.vealTotalPaise }

        val denaBillsPeriod = billsInPeriod.filter { it.type == LedgerType.DENA.name }.sumOf { it.totalBillPaise }
        val denaPaymentsPeriod = paymentsInPeriod.filter { it.type == LedgerType.DENA.name }.sumOf { it.amountPaise }

        val aanaBillsPeriod = billsInPeriod.filter { it.type == LedgerType.AANA.name }.sumOf { it.totalBillPaise }
        val aanaPaymentsPeriod = paymentsInPeriod.filter { it.type == LedgerType.AANA.name }.sumOf { it.amountPaise }

        // Prior balance before fromTs
        val denaInitialOpening = allParties.filter { it.type == LedgerType.DENA.name }.sumOf { it.openingBalancePaise }
        val denaBillsBefore = allBills.filter { it.type == LedgerType.DENA.name && it.timestamp < fromTs }.sumOf { it.totalBillPaise }
        val denaPayBefore = allPayments.filter { it.type == LedgerType.DENA.name && it.timestamp < fromTs }.sumOf { it.amountPaise }
        val openingDenaBeforePeriod = denaInitialOpening + denaBillsBefore - denaPayBefore

        val aanaInitialOpening = allParties.filter { it.type == LedgerType.AANA.name }.sumOf { it.openingBalancePaise }
        val aanaBillsBefore = allBills.filter { it.type == LedgerType.AANA.name && it.timestamp < fromTs }.sumOf { it.totalBillPaise }
        val aanaPayBefore = allPayments.filter { it.type == LedgerType.AANA.name && it.timestamp < fromTs }.sumOf { it.amountPaise }
        val openingAanaBeforePeriod = aanaInitialOpening + aanaBillsBefore - aanaPayBefore

        val closingDena = openingDenaBeforePeriod + denaBillsPeriod - denaPaymentsPeriod
        val closingAana = openingAanaBeforePeriod + aanaBillsPeriod - aanaPaymentsPeriod

        val officePeriod = allOffice.filter { it.timestamp in fromTs..toTs }
        val apsarGiven = officePeriod.filter { it.direction == "GIVEN" }.sumOf { it.amountPaise }
        val apsarTaken = officePeriod.filter { it.direction == "TAKEN" }.sumOf { it.amountPaise }

        return MonthlyReportSummary(
            fromDate = fromDateStr,
            toDate = toDateStr,
            bigAnimalCount = bigAnimals,
            bigAnimalWeightGrams = bigWeight,
            bigAnimalTotalPaise = bigTotal,
            vealWeightGrams = vealWeight,
            vealTotalPaise = vealTotal,
            combinedWeightGrams = bigWeight + vealWeight,
            combinedMaalPaise = bigTotal + vealTotal,
            periodDenaBillsPaise = denaBillsPeriod,
            periodDenaPaymentsPaise = denaPaymentsPeriod,
            periodAanaBillsPaise = aanaBillsPeriod,
            periodAanaPaymentsPaise = aanaPaymentsPeriod,
            openingDenaBeforePeriodPaise = openingDenaBeforePeriod,
            openingAanaBeforePeriodPaise = openingAanaBeforePeriod,
            closingDenaAtEndPaise = closingDena,
            closingAanaAtEndPaise = closingAana,
            apsarGivenInPeriodPaise = apsarGiven,
            apsarTakenInPeriodPaise = apsarTaken
        )
    }
}
