package com.haweli.hisab.data

import android.content.Context
import android.os.Build
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.haweli.hisab.model.*
import com.haweli.hisab.util.CurrencyUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * HAWELI Unified Real-Time Repository
 * - Synchronizes across multiple Android devices in real time via Firebase Firestore SnapshotListeners
 * - Uses Firestore Transactions for atomic writes & Audit Log recording
 * - Maintains offline persistence so data is never lost when internet is unavailable
 */
class HaweliRepository(private val context: Context) {

    private val localPrefs = context.getSharedPreferences("haweli_offline_ledger_store", Context.MODE_PRIVATE)

    private val _cities = MutableStateFlow<List<CityRecord>>(emptyList())
    val cities: StateFlow<List<CityRecord>> = _cities.asStateFlow()

    private val _parties = MutableStateFlow<List<PartyRecord>>(emptyList())
    val parties: StateFlow<List<PartyRecord>> = _parties.asStateFlow()

    private val _bills = MutableStateFlow<List<BillTransaction>>(emptyList())
    val bills: StateFlow<List<BillTransaction>> = _bills.asStateFlow()

    private val _payments = MutableStateFlow<List<PaymentTransaction>>(emptyList())
    val payments: StateFlow<List<PaymentTransaction>> = _payments.asStateFlow()

    private val _officeTransactions = MutableStateFlow<List<OfficeApsarTransaction>>(emptyList())
    val officeTransactions: StateFlow<List<OfficeApsarTransaction>> = _officeTransactions.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    private val _mobileUsers = MutableStateFlow<List<AuthorizedMobileUser>>(emptyList())
    val mobileUsers: StateFlow<List<AuthorizedMobileUser>> = _mobileUsers.asStateFlow()

    private val _isCloudSynced = MutableStateFlow(false)
    val isCloudSynced: StateFlow<Boolean> = _isCloudSynced.asStateFlow()

    private var registrations = mutableListOf<ListenerRegistration>()

    init {
        seedDefaultDataIfEmpty()
        attachFirestoreRealtimeListeners()
    }

    private fun seedDefaultDataIfEmpty() {
        if (!localPrefs.getBoolean("seeded_initial_cities", false)) {
            val now = System.currentTimeMillis()
            val defaultCities = listOf(
                CityRecord(id = "city_baramati", name = "बारामती", section = "BOTH", createdAt = now, updatedAt = now, createdBy = "system"),
                CityRecord(id = "city_bhoom", name = "भूम", section = "BOTH", createdAt = now, updatedAt = now, createdBy = "system"),
                CityRecord(id = "city_dharashiv", name = "धाराशिव", section = "BOTH", createdAt = now, updatedAt = now, createdBy = "system")
            )
            _cities.value = defaultCities
            localPrefs.edit().putBoolean("seeded_initial_cities", true).apply()
        }
    }

    fun attachFirestoreRealtimeListeners() {
        registrations.forEach { it.remove() }
        registrations.clear()

        val db: FirebaseFirestore = FirebaseConfigManager.getFirestoreOrNull(context) ?: run {
            _isCloudSynced.value = false
            return
        }

        _isCloudSynced.value = true

        // 1. Cities Real-time Listener
        registrations.add(
            db.collection("haweli_cities").addSnapshotListener { snap, err ->
                if (err == null && snap != null) {
                    val list = snap.documents.mapNotNull { doc ->
                        CityRecord(
                            id = doc.id,
                            name = doc.getString("name") ?: "",
                            section = doc.getString("section") ?: "BOTH",
                            createdAt = doc.getLong("createdAt") ?: 0L,
                            updatedAt = doc.getLong("updatedAt") ?: 0L,
                            createdBy = doc.getString("createdBy") ?: "admin"
                        )
                    }.sortedBy { it.name }
                    if (list.isNotEmpty()) _cities.value = list
                }
            }
        )

        // 2. Parties Real-time Listener
        registrations.add(
            db.collection("haweli_parties").addSnapshotListener { snap, err ->
                if (err == null && snap != null) {
                    val list = snap.documents.mapNotNull { doc ->
                        PartyRecord(
                            id = doc.id,
                            name = doc.getString("name") ?: "",
                            mobile = doc.getString("mobile") ?: "",
                            cityId = doc.getString("cityId") ?: "",
                            cityName = doc.getString("cityName") ?: "",
                            address = doc.getString("address") ?: "",
                            type = doc.getString("type") ?: LedgerType.DENA.name,
                            openingBalancePaise = doc.getLong("openingBalancePaise") ?: 0L,
                            entryDate = doc.getString("entryDate") ?: "",
                            entryTimestamp = doc.getLong("entryTimestamp") ?: 0L,
                            createdAt = doc.getLong("createdAt") ?: 0L,
                            updatedAt = doc.getLong("updatedAt") ?: 0L,
                            createdBy = doc.getString("createdBy") ?: "admin"
                        )
                    }.sortedBy { it.name }
                    _parties.value = list
                }
            }
        )

        // 3. Bills (Maal / Dispatch) Real-time Listener
        registrations.add(
            db.collection("haweli_bills").addSnapshotListener { snap, err ->
                if (err == null && snap != null) {
                    val list = snap.documents.mapNotNull { doc ->
                        BillTransaction(
                            id = doc.id,
                            partyId = doc.getString("partyId") ?: "",
                            partyName = doc.getString("partyName") ?: "",
                            cityId = doc.getString("cityId") ?: "",
                            cityName = doc.getString("cityName") ?: "",
                            type = doc.getString("type") ?: LedgerType.DENA.name,
                            date = doc.getString("date") ?: "",
                            timestamp = doc.getLong("timestamp") ?: 0L,
                            vehicleNumber = doc.getString("vehicleNumber") ?: "",
                            bigAnimalCount = (doc.getLong("bigAnimalCount") ?: 0L).toInt(),
                            bigAnimalWeightGrams = doc.getLong("bigAnimalWeightGrams") ?: 0L,
                            bigAnimalRatePaise = doc.getLong("bigAnimalRatePaise") ?: 0L,
                            bigAnimalTotalPaise = doc.getLong("bigAnimalTotalPaise") ?: 0L,
                            vealWeightGrams = doc.getLong("vealWeightGrams") ?: 0L,
                            vealRatePaise = doc.getLong("vealRatePaise") ?: 0L,
                            vealTotalPaise = doc.getLong("vealTotalPaise") ?: 0L,
                            otherExpensePaise = doc.getLong("otherExpensePaise") ?: 0L,
                            totalBillPaise = doc.getLong("totalBillPaise") ?: 0L,
                            note = doc.getString("note") ?: "",
                            createdAt = doc.getLong("createdAt") ?: 0L,
                            updatedAt = doc.getLong("updatedAt") ?: 0L,
                            createdBy = doc.getString("createdBy") ?: "admin"
                        )
                    }.sortedByDescending { it.timestamp }
                    _bills.value = list
                }
            }
        )

        // 4. Payments Real-time Listener
        registrations.add(
            db.collection("haweli_payments").addSnapshotListener { snap, err ->
                if (err == null && snap != null) {
                    val list = snap.documents.mapNotNull { doc ->
                        PaymentTransaction(
                            id = doc.id,
                            partyId = doc.getString("partyId") ?: "",
                            partyName = doc.getString("partyName") ?: "",
                            cityId = doc.getString("cityId") ?: "",
                            cityName = doc.getString("cityName") ?: "",
                            type = doc.getString("type") ?: LedgerType.DENA.name,
                            date = doc.getString("date") ?: "",
                            timestamp = doc.getLong("timestamp") ?: 0L,
                            amountPaise = doc.getLong("amountPaise") ?: 0L,
                            paymentMode = doc.getString("paymentMode") ?: "नकद (Cash)",
                            note = doc.getString("note") ?: "",
                            createdAt = doc.getLong("createdAt") ?: 0L,
                            updatedAt = doc.getLong("updatedAt") ?: 0L,
                            createdBy = doc.getString("createdBy") ?: "admin"
                        )
                    }.sortedByDescending { it.timestamp }
                    _payments.value = list
                }
            }
        )

        // 5. Office (Apsar Bhai) Real-time Listener
        registrations.add(
            db.collection("haweli_office_apsar").addSnapshotListener { snap, err ->
                if (err == null && snap != null) {
                    val list = snap.documents.mapNotNull { doc ->
                        OfficeApsarTransaction(
                            id = doc.id,
                            direction = doc.getString("direction") ?: "GIVEN",
                            personName = doc.getString("personName") ?: "",
                            date = doc.getString("date") ?: "",
                            timestamp = doc.getLong("timestamp") ?: 0L,
                            amountPaise = doc.getLong("amountPaise") ?: 0L,
                            reason = doc.getString("reason") ?: "",
                            note = doc.getString("note") ?: "",
                            createdAt = doc.getLong("createdAt") ?: 0L,
                            updatedAt = doc.getLong("updatedAt") ?: 0L,
                            createdBy = doc.getString("createdBy") ?: "admin"
                        )
                    }.sortedByDescending { it.timestamp }
                    _officeTransactions.value = list
                }
            }
        )

        // 6. Audit Logs Real-time Listener
        registrations.add(
            db.collection("haweli_audit_logs").addSnapshotListener { snap, err ->
                if (err == null && snap != null) {
                    val list = snap.documents.mapNotNull { doc ->
                        AuditLogEntry(
                            id = doc.id,
                            action = doc.getString("action") ?: "",
                            module = doc.getString("module") ?: "",
                            summaryHindi = doc.getString("summaryHindi") ?: "",
                            performedBy = doc.getString("performedBy") ?: "",
                            deviceName = doc.getString("deviceName") ?: "",
                            timestamp = doc.getLong("timestamp") ?: 0L,
                            dateFormatted = doc.getString("dateFormatted") ?: ""
                        )
                    }.sortedByDescending { it.timestamp }
                    _auditLogs.value = list
                }
            }
        )
    }

    private fun recordAudit(action: String, module: String, summaryHindi: String, user: String) {
        val now = System.currentTimeMillis()
        val entry = AuditLogEntry(
            id = "audit_${now}_${UUID.randomUUID().toString().take(6)}",
            action = action,
            module = module,
            summaryHindi = summaryHindi,
            performedBy = user,
            deviceName = "${Build.MANUFACTURER} ${Build.MODEL}",
            timestamp = now,
            dateFormatted = CurrencyUtils.formatDateDdMmYyyy(now)
        )
        _auditLogs.value = listOf(entry) + _auditLogs.value
        FirebaseConfigManager.getFirestoreOrNull(context)
            ?.collection("haweli_audit_logs")
            ?.document(entry.id)
            ?.set(entry)
    }

    // --- CITY CRUD ---
    fun saveCity(city: CityRecord, user: String) {
        val now = System.currentTimeMillis()
        val finalCity = if (city.id.isBlank()) {
            city.copy(id = "city_${now}_${UUID.randomUUID().toString().take(5)}", createdAt = now, updatedAt = now, createdBy = user)
        } else {
            city.copy(updatedAt = now)
        }
        _cities.value = (_cities.value.filterNot { it.id == finalCity.id } + finalCity).sortedBy { it.name }
        FirebaseConfigManager.getFirestoreOrNull(context)?.let { db ->
            db.runTransaction { tx ->
                tx.set(db.collection("haweli_cities").document(finalCity.id), finalCity, SetOptions.merge())
            }
        }
        recordAudit("SAVE", "CITY", "शहर '${finalCity.name}' सेव किया गया", user)
    }

    fun deleteCity(cityId: String, user: String) {
        val target = _cities.value.find { it.id == cityId } ?: return
        _cities.value = _cities.value.filterNot { it.id == cityId }
        FirebaseConfigManager.getFirestoreOrNull(context)
            ?.collection("haweli_cities")?.document(cityId)?.delete()
        recordAudit("DELETE", "CITY", "शहर '${target.name}' हटाया गया", user)
    }

    // --- PARTY CRUD ---
    fun saveParty(party: PartyRecord, user: String) {
        val now = System.currentTimeMillis()
        val finalParty = if (party.id.isBlank()) {
            party.copy(
                id = "party_${now}_${UUID.randomUUID().toString().take(5)}",
                entryTimestamp = CurrencyUtils.parseDdMmYyyy(party.entryDate),
                createdAt = now,
                updatedAt = now,
                createdBy = user
            )
        } else {
            party.copy(
                entryTimestamp = CurrencyUtils.parseDdMmYyyy(party.entryDate),
                updatedAt = now
            )
        }
        _parties.value = (_parties.value.filterNot { it.id == finalParty.id } + finalParty).sortedBy { it.name }
        FirebaseConfigManager.getFirestoreOrNull(context)?.let { db ->
            db.runTransaction { tx ->
                tx.set(db.collection("haweli_parties").document(finalParty.id), finalParty, SetOptions.merge())
            }
        }
        recordAudit(
            "SAVE",
            finalParty.type,
            "पार्टी '${finalParty.name}' (${finalParty.cityName}) - शुरुआती बाकी ${CurrencyUtils.formatIndianRupees(finalParty.openingBalancePaise)}",
            user
        )
    }

    fun deletePartyAndCascade(partyId: String, user: String) {
        val target = _parties.value.find { it.id == partyId } ?: return
        _parties.value = _parties.value.filterNot { it.id == partyId }
        _bills.value = _bills.value.filterNot { it.partyId == partyId }
        _payments.value = _payments.value.filterNot { it.partyId == partyId }

        FirebaseConfigManager.getFirestoreOrNull(context)?.let { db ->
            db.collection("haweli_parties").document(partyId).delete()
        }
        recordAudit("DELETE", target.type, "पार्टी '${target.name}' और उसका पूरा हिसाब हटाया गया", user)
    }

    // --- BILL / MAAL TRANSACTION CRUD ---
    fun saveBill(bill: BillTransaction, user: String) {
        val now = System.currentTimeMillis()
        val bigTotal = CurrencyUtils.calculateWeightXRatePaise(bill.bigAnimalWeightGrams, bill.bigAnimalRatePaise)
        val vealTotal = CurrencyUtils.calculateWeightXRatePaise(bill.vealWeightGrams, bill.vealRatePaise)
        val grandTotal = bigTotal + vealTotal + bill.otherExpensePaise

        val finalBill = bill.copy(
            id = if (bill.id.isBlank()) "bill_${now}_${UUID.randomUUID().toString().take(5)}" else bill.id,
            timestamp = CurrencyUtils.parseDdMmYyyy(bill.date),
            bigAnimalTotalPaise = bigTotal,
            vealTotalPaise = vealTotal,
            totalBillPaise = grandTotal,
            createdAt = if (bill.id.isBlank()) now else bill.createdAt,
            updatedAt = now,
            createdBy = user
        )

        _bills.value = (_bills.value.filterNot { it.id == finalBill.id } + finalBill).sortedByDescending { it.timestamp }
        FirebaseConfigManager.getFirestoreOrNull(context)?.let { db ->
            db.runTransaction { tx ->
                tx.set(db.collection("haweli_bills").document(finalBill.id), finalBill, SetOptions.merge())
            }
        }
        recordAudit(
            "SAVE_BILL",
            finalBill.type,
            "${finalBill.partyName}: माल बिल ${CurrencyUtils.formatIndianRupees(finalBill.totalBillPaise)} (${finalBill.date})",
            user
        )
    }

    fun deleteBill(billId: String, user: String) {
        val target = _bills.value.find { it.id == billId } ?: return
        _bills.value = _bills.value.filterNot { it.id == billId }
        FirebaseConfigManager.getFirestoreOrNull(context)
            ?.collection("haweli_bills")?.document(billId)?.delete()
        recordAudit(
            "DELETE_BILL",
            target.type,
            "${target.partyName} का बिल ${CurrencyUtils.formatIndianRupees(target.totalBillPaise)} हटाया गया",
            user
        )
    }

    // --- PAYMENT TRANSACTION CRUD ---
    fun savePayment(payment: PaymentTransaction, user: String) {
        val now = System.currentTimeMillis()
        val finalPay = payment.copy(
            id = if (payment.id.isBlank()) "pay_${now}_${UUID.randomUUID().toString().take(5)}" else payment.id,
            timestamp = CurrencyUtils.parseDdMmYyyy(payment.date),
            createdAt = if (payment.id.isBlank()) now else payment.createdAt,
            updatedAt = now,
            createdBy = user
        )
        _payments.value = (_payments.value.filterNot { it.id == finalPay.id } + finalPay).sortedByDescending { it.timestamp }
        FirebaseConfigManager.getFirestoreOrNull(context)?.let { db ->
            db.runTransaction { tx ->
                tx.set(db.collection("haweli_payments").document(finalPay.id), finalPay, SetOptions.merge())
            }
        }
        recordAudit(
            "SAVE_PAYMENT",
            finalPay.type,
            "${finalPay.partyName}: भुगतान ${CurrencyUtils.formatIndianRupees(finalPay.amountPaise)} (${finalPay.paymentMode})",
            user
        )
    }

    fun deletePayment(paymentId: String, user: String) {
        val target = _payments.value.find { it.id == paymentId } ?: return
        _payments.value = _payments.value.filterNot { it.id == paymentId }
        FirebaseConfigManager.getFirestoreOrNull(context)
            ?.collection("haweli_payments")?.document(paymentId)?.delete()
        recordAudit(
            "DELETE_PAYMENT",
            target.type,
            "${target.partyName} का भुगतान ${CurrencyUtils.formatIndianRupees(target.amountPaise)} हटाया गया",
            user
        )
    }

    // --- OFFICE (APSAR BHAI) CRUD ---
    fun saveOfficeTransaction(entry: OfficeApsarTransaction, user: String) {
        val now = System.currentTimeMillis()
        val finalEntry = entry.copy(
            id = if (entry.id.isBlank()) "apsar_${now}_${UUID.randomUUID().toString().take(5)}" else entry.id,
            timestamp = CurrencyUtils.parseDdMmYyyy(entry.date),
            createdAt = if (entry.id.isBlank()) now else entry.createdAt,
            updatedAt = now,
            createdBy = user
        )
        _officeTransactions.value = (_officeTransactions.value.filterNot { it.id == finalEntry.id } + finalEntry).sortedByDescending { it.timestamp }
        FirebaseConfigManager.getFirestoreOrNull(context)?.let { db ->
            db.runTransaction { tx ->
                tx.set(db.collection("haweli_office_apsar").document(finalEntry.id), finalEntry, SetOptions.merge())
            }
        }
        val label = if (finalEntry.direction == "GIVEN") "दिए" else "लिए"
        recordAudit(
            "SAVE_OFFICE",
            "OFFICE_APSAR",
            "APSAR BHAI (${label}): ${finalEntry.personName} - ${CurrencyUtils.formatIndianRupees(finalEntry.amountPaise)}",
            user
        )
    }

    fun deleteOfficeTransaction(entryId: String, user: String) {
        val target = _officeTransactions.value.find { it.id == entryId } ?: return
        _officeTransactions.value = _officeTransactions.value.filterNot { it.id == entryId }
        FirebaseConfigManager.getFirestoreOrNull(context)
            ?.collection("haweli_office_apsar")?.document(entryId)?.delete()
        recordAudit(
            "DELETE_OFFICE",
            "OFFICE_APSAR",
            "APSAR BHAI एंट्री (${target.personName}: ${CurrencyUtils.formatIndianRupees(target.amountPaise)}) हटाई गई",
            user
        )
    }
}
