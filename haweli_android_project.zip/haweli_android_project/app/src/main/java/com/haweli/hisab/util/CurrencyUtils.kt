package com.haweli.hisab.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * HAWELI Calculation Accuracy Engine
 * Uses strictly BigDecimal and Long (Integer Paise: 1 Rupee = 100 Paise)
 * to prevent any floating-point rounding errors.
 * Dena and Aana are strictly isolated and never auto-adjusted against each other.
 */
object CurrencyUtils {

    private val PAISA_MULTIPLIER = BigDecimal("100")
    private val GRAMS_DIVISOR = BigDecimal("1000")

    /**
     * Converts a Rupee string (e.g. "500000" or "1250.50") to exact Integer Paise (Long).
     */
    fun rupeesToPaise(rupeesStr: String): Long {
        val clean = rupeesStr.trim().replace(",", "").replace("₹", "")
        if (clean.isEmpty()) return 0L
        return try {
            BigDecimal(clean)
                .multiply(PAISA_MULTIPLIER)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        } catch (e: Exception) {
            0L
        }
    }

    /**
     * Converts KG string (e.g. "1450.500") to integer Grams (Long, 1 KG = 1000 Grams).
     */
    fun kgToGrams(kgStr: String): Long {
        val clean = kgStr.trim().replace(",", "")
        if (clean.isEmpty()) return 0L
        return try {
            BigDecimal(clean)
                .multiply(GRAMS_DIVISOR)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        } catch (e: Exception) {
            0L
        }
    }

    /**
     * Formula: कुल रकम (Paise) = कुल वजन (KG) × प्रति KG रेट (Paise)
     * Uses exact BigDecimal arithmetic: (weightGrams * ratePerKgPaise) / 1000
     */
    fun calculateWeightXRatePaise(weightGrams: Long, ratePerKgPaise: Long): Long {
        if (weightGrams <= 0L || ratePerKgPaise <= 0L) return 0L
        return BigDecimal.valueOf(weightGrams)
            .multiply(BigDecimal.valueOf(ratePerKgPaise))
            .divide(GRAMS_DIVISOR, 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /**
     * Formats Grams back to clean KG string (e.g. "1,250.50 KG" or "450 KG").
     */
    fun formatGramsToKg(grams: Long): String {
        val bd = BigDecimal.valueOf(grams).divide(GRAMS_DIVISOR, 3, RoundingMode.HALF_UP)
            .stripTrailingZeros()
        return "${bd.toPlainString()} KG"
    }

    /**
     * Formats exact Paise (Long) into Indian Rupee format (₹5,00,000 or ₹12,345.50).
     */
    fun formatIndianRupees(paise: Long, includeSymbol: Boolean = true): String {
        val isNegative = paise < 0
        val absPaise = kotlin.math.abs(paise)
        val rupees = absPaise / 100
        val remPaise = absPaise % 100

        val rupeesStr = formatIndianGrouping(rupees)
        val decimalPart = if (remPaise > 0) String.format(Locale.US, ".%02d", remPaise) else ""
        val prefix = (if (isNegative) "-" else "") + (if (includeSymbol) "₹" else "")
        return "$prefix$rupeesStr$decimalPart"
    }

    private fun formatIndianGrouping(number: Long): String {
        val s = number.toString()
        if (s.length <= 3) return s
        val lastThree = s.substring(s.length - 3)
        val otherNumbers = s.substring(0, s.length - 3)
        val regex = Regex("\\B(?=(\\d{2})+(?!\\d))")
        return otherNumbers.replace(regex, ",") + "," + lastThree
    }

    /**
     * Formats date strictly in DD/MM/YYYY format.
     */
    fun formatDateDdMmYyyy(timestampMillis: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        return sdf.format(Date(timestampMillis))
    }

    /**
     * Parses DD/MM/YYYY to epoch start-of-day milliseconds.
     */
    fun parseDdMmYyyy(dateStr: String): Long {
        return try {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.US)
            sdf.isLenient = false
            sdf.parse(dateStr)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }
}
