package com.haweli.hisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.hisab.data.FirebaseConfigManager
import com.haweli.hisab.model.*
import com.haweli.hisab.ui.theme.*
import com.haweli.hisab.util.CurrencyUtils
import com.haweli.hisab.viewmodel.HaweliViewModel

enum class HaweliScreen(val titleHindi: String) {
    HOME("HAWELI डैशबोर्ड"),
    DENA("देना (Dena)"),
    AANA("आना (Aana)"),
    OFFICE_APSAR("ऑफिस – APSAR BHAI"),
    MONTHLY_REPORT("महीने का हिसाब"),
    ALL_PARTIES("सभी पार्टियां"),
    REPORTS_PRINT("रिपोर्ट, ऑडिट और बैकअप"),
    SETTINGS("सेटिंग और Firebase Lock")
}

class MainActivity : ComponentActivity() {

    private val viewModel: HaweliViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HaweliTheme {
                HaweliMainApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HaweliMainApp(viewModel: HaweliViewModel) {
    var currentScreen by remember { mutableStateOf(HaweliScreen.HOME) }
    var selectedPartyForLedger by remember { mutableStateOf<PartyRecord?>(null) }

    val cities by viewModel.repository.cities.collectAsState()
    val parties by viewModel.repository.parties.collectAsState()
    val bills by viewModel.repository.bills.collectAsState()
    val payments by viewModel.repository.payments.collectAsState()
    val officeTxs by viewModel.repository.officeTransactions.collectAsState()
    val auditLogs by viewModel.repository.auditLogs.collectAsState()
    val isCloudSynced by viewModel.repository.isCloudSynced.collectAsState()
    val isAdmin by viewModel.isAdminLoggedIn.collectAsState()
    val currentUser by viewModel.currentUsername.collectAsState()

    val denaSummary = remember(parties, bills, payments) {
        viewModel.computeDashboardSummary(LedgerType.DENA)
    }
    val aanaSummary = remember(parties, bills, payments) {
        viewModel.computeDashboardSummary(LedgerType.AANA)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = currentScreen.titleHindi,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (isCloudSynced) "Firebase Real-Time Sync: चालू" else "ऑफ़लाइन कैश मोड (Local Safe)",
                            fontSize = 11.sp,
                            color = Color(0xFFA7F3D0)
                        )
                    }
                },
                navigationIcon = {
                    if (currentScreen != HaweliScreen.HOME || selectedPartyForLedger != null) {
                        IconButton(onClick = {
                            if (selectedPartyForLedger != null) {
                                selectedPartyForLedger = null
                            } else {
                                currentScreen = HaweliScreen.HOME
                            }
                        }) {
                            Icon(Icons.Default.Home, contentDescription = "होम पर जाएं", tint = Color.White)
                        }
                    }
                },
                actions = {
                    if (currentScreen != HaweliScreen.HOME) {
                        TextButton(onClick = {
                            selectedPartyForLedger = null
                            currentScreen = HaweliScreen.HOME
                        }) {
                            Text("होम पेज", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = HaweliDarkBlue)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(SurfaceLight)
        ) {
            if (selectedPartyForLedger != null) {
                PartyLedgerDetailView(
                    party = selectedPartyForLedger!!,
                    viewModel = viewModel,
                    currentUser = currentUser,
                    onBack = { selectedPartyForLedger = null }
                )
            } else {
                when (currentScreen) {
                    HaweliScreen.HOME -> DashboardHomeView(
                        denaSummary = denaSummary,
                        aanaSummary = aanaSummary,
                        isAdmin = isAdmin,
                        onNavigate = { currentScreen = it }
                    )
                    HaweliScreen.DENA -> CityPartySectionView(
                        ledgerType = LedgerType.DENA,
                        cities = cities,
                        parties = parties.filter { it.type == LedgerType.DENA.name },
                        viewModel = viewModel,
                        currentUser = currentUser,
                        onOpenPartyLedger = { selectedPartyForLedger = it }
                    )
                    HaweliScreen.AANA -> CityPartySectionView(
                        ledgerType = LedgerType.AANA,
                        cities = cities,
                        parties = parties.filter { it.type == LedgerType.AANA.name },
                        viewModel = viewModel,
                        currentUser = currentUser,
                        onOpenPartyLedger = { selectedPartyForLedger = it }
                    )
                    HaweliScreen.OFFICE_APSAR -> OfficeApsarBhaiView(
                        transactions = officeTxs,
                        viewModel = viewModel,
                        currentUser = currentUser
                    )
                    HaweliScreen.MONTHLY_REPORT -> MonthlyReportView(
                        viewModel = viewModel
                    )
                    HaweliScreen.ALL_PARTIES -> AllPartiesManagementView(
                        cities = cities,
                        parties = parties,
                        viewModel = viewModel,
                        onOpenPartyLedger = { selectedPartyForLedger = it }
                    )
                    HaweliScreen.REPORTS_PRINT -> AuditAndReportsView(
                        auditLogs = auditLogs,
                        parties = parties,
                        viewModel = viewModel,
                        onOpenPartyLedger = { selectedPartyForLedger = it }
                    )
                    HaweliScreen.SETTINGS -> SettingsAndAdminView(
                        viewModel = viewModel,
                        isAdmin = isAdmin
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardHomeView(
    denaSummary: com.haweli.hisab.viewmodel.DashboardCardSummary,
    aanaSummary: com.haweli.hisab.viewmodel.DashboardCardSummary,
    isAdmin: Boolean,
    onNavigate: (HaweliScreen) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Card 1: देना (DENA)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("पहला कार्ड – देना (Dena)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = DenaRed)
                Divider(color = Color(0xFFFECACA))
                SummaryRow("कुल देना:", CurrencyUtils.formatIndianRupees(denaSummary.totalPayableOrReceivablePaise))
                SummaryRow("कुल भुगतान (दिए गए):", CurrencyUtils.formatIndianRupees(denaSummary.totalPaidOrReceivedPaise))
                SummaryRow("आज का भुगतान:", CurrencyUtils.formatIndianRupees(denaSummary.todayPaidOrReceivedPaise))
                SummaryRow("पुरानी बाकी:", CurrencyUtils.formatIndianRupees(denaSummary.oldOpeningBalancePaise))
                SummaryRow(
                    "वर्तमान बाकी देना:",
                    CurrencyUtils.formatIndianRupees(denaSummary.currentRemainingPaise),
                    bold = true,
                    valueColor = DenaRed
                )
            }
        }

        // Card 2: आना (AANA)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("दूसरा कार्ड – आना (Aana)", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = AanaGreen)
                Divider(color = Color(0xFFBBF7D0))
                SummaryRow("कुल आना:", CurrencyUtils.formatIndianRupees(aanaSummary.totalPayableOrReceivablePaise))
                SummaryRow("कुल प्राप्त भुगतान:", CurrencyUtils.formatIndianRupees(aanaSummary.totalPaidOrReceivedPaise))
                SummaryRow("आज आया पैसा:", CurrencyUtils.formatIndianRupees(aanaSummary.todayPaidOrReceivedPaise))
                SummaryRow("पुरानी बाकी:", CurrencyUtils.formatIndianRupees(aanaSummary.oldOpeningBalancePaise))
                SummaryRow(
                    "वर्तमान बाकी आना:",
                    CurrencyUtils.formatIndianRupees(aanaSummary.currentRemainingPaise),
                    bold = true,
                    valueColor = AanaGreen
                )
            }
        }

        Text("मुख्य विकल्प (Navigation)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = HaweliDarkBlue)

        val menuItems = listOf(
            HaweliScreen.DENA to "1. देना (शहर और पार्टी अनुसार हिसाब)",
            HaweliScreen.AANA to "2. आना (गाड़ी और पार्टी अनुसार हिसाब)",
            HaweliScreen.OFFICE_APSAR to "3. ऑफिस – APSAR BHAI लेन-देन",
            HaweliScreen.MONTHLY_REPORT to "4. महीने का हिसाब (Date Range रिपोर्ट)",
            HaweliScreen.ALL_PARTIES to "5. सभी पार्टियां (खोज और फ़िल्टर)",
            HaweliScreen.REPORTS_PRINT to "6. रिपोर्ट, प्रिंट, रिमाइंडर और ऑडिट लॉग",
            HaweliScreen.SETTINGS to "7. सेटिंग, Admin Login और Firebase Lock"
        )

        menuItems.forEach { (screen, label) ->
            Button(
                onClick = { onNavigate(screen) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkBlue)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                    Icon(Icons.Default.ArrowForward, contentDescription = null, tint = HaweliEmerald)
                }
            }
        }
    }
}

@Composable
fun SummaryRow(label: String, value: String, bold: Boolean = false, valueColor: Color = HaweliDarkBlue) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, fontSize = if (bold) 16.sp else 14.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = if (bold) 17.sp else 14.sp, color = valueColor)
    }
}
