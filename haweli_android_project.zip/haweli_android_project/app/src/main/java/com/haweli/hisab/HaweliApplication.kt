package com.haweli.hisab

import android.app.Application
import com.haweli.hisab.data.FirebaseConfigManager

class HaweliApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Auto-initialize Firebase if configuration is stored and locked
        FirebaseConfigManager.initializeIfConfigured(this)
    }
}
