package com.haweli.hisab.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import com.haweli.hisab.model.PartyComputedSummary
import com.haweli.hisab.viewmodel.MonthlyReportSummary
import java.io.File
import java.io.FileOutputStream

/**
 * Exports Party Statements & Monthly Reports to PDF, CSV (Excel compatible UTF-8 BOM), and Android PrintManager.
 */
object ReportExporter {

    fun exportMonthlyReportCsv(context: Context, report: MonthlyReportSummary, partySummaries: List<PartyComputedSummary>): File {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, "HAWELI_Report_${report.fromDate.replace("/", "-")}_to_${report.toDate.replace("/", "-")}.csv")

        FileOutputStream(file).use { fos ->
            // Write UTF-8 BOM so Microsoft Excel renders Hindi Devanagari script cleanly
            fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
            val sb = StringBuilder()
            sb.appendLine("HAWELI व्यापारिक हिसाब-किताब रिपोर्ट,${report.fromDate} से ${report.toDate}")
            sb.appendLine()
            sb.appendLine("विवरण,मान")
            sb.appendLine("बड़े जानवर संख्या,${report.bigAnimalCount}")
            sb.appendLine("बड़े जानवर कुल वजन,${CurrencyUtils.formatGramsToKg(report.bigAnimalWeightGrams)}")
            sb.appendLine("बड़े जानवर कुल रकम,"${CurrencyUtils.formatIndianRupees(report.bigAnimalTotalPaise)}"")
            sb.appendLine("Veal माल कुल वजन,${CurrencyUtils.formatGramsToKg(report.vealWeightGrams)}")
            sb.appendLine("Veal माल कुल रकम,"${CurrencyUtils.formatIndianRupees(report.vealTotalPaise)}"")
            sb.appendLine("इस अवधि में कुल देना बना,"${CurrencyUtils.formatIndianRupees(report.periodDenaBillsPaise)}"")
            sb.appendLine("इस अवधि में कुल भुगतान दिया,"${CurrencyUtils.formatIndianRupees(report.periodDenaPaymentsPaise)}"")
            sb.appendLine("महीने के अंत में कुल देना बाकी,"${CurrencyUtils.formatIndianRupees(report.closingDenaAtEndPaise)}"")
            sb.appendLine("इस अवधि में कुल आना बना,"${CurrencyUtils.formatIndianRupees(report.periodAanaBillsPaise)}"")
            sb.appendLine("इस अवधि में कुल भुगतान प्राप्त,"${CurrencyUtils.formatIndianRupees(report.periodAanaPaymentsPaise)}"")
            sb.appendLine("महीने के अंत में कुल आना बाकी,"${CurrencyUtils.formatIndianRupees(report.closingAanaAtEndPaise)}"")
            sb.appendLine()
            sb.appendLine("पार्टी का नाम,शहर,विभाग,पुरानी बाकी,नए बिल,कुल रकम,भुगतान,वर्तमान बाकी")
            for (ps in partySummaries) {
                val sec = if (ps.party.type == "DENA") "देना" else "आना"
                sb.appendLine(
                    ""${ps.party.name}","${ps.party.cityName}",$sec," +
                    ""${CurrencyUtils.formatIndianRupees(ps.party.openingBalancePaise)}"," +
                    ""${CurrencyUtils.formatIndianRupees(ps.newBillsTotalPaise)}"," +
                    ""${CurrencyUtils.formatIndianRupees(ps.grandTotalPayableOrReceivablePaise)}"," +
                    ""${CurrencyUtils.formatIndianRupees(ps.totalPaymentsPaise)}"," +
                    ""${CurrencyUtils.formatIndianRupees(ps.remainingBalancePaise)}""
                )
            }
            fos.write(sb.toString().toByteArray(Charsets.UTF_8))
        }
        return file
    }

    fun exportPartyLedgerPdf(context: Context, summary: PartyComputedSummary): File {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, "HAWELI_Ledger_${summary.party.name.replace(" ", "_")}.pdf")

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            isFakeBoldText = true
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 13f
        }

        var y = 50f
        canvas.drawText("HAWELI – पार्टी खाता विवरण (Party Statement)", 40f, y, titlePaint)
        y += 30f
        canvas.drawText("पार्टी का नाम: ${summary.party.name} (${summary.party.cityName})", 40f, y, bodyPaint)
        y += 22f
        canvas.drawText("विभाग: ${if (summary.party.type == "DENA") "देना (Dena)" else "आना (Aana)"} | मोबाइल: ${summary.party.mobile}", 40f, y, bodyPaint)
        y += 28f
        canvas.drawText("शुरुआती पुरानी बाकी: ${CurrencyUtils.formatIndianRupees(summary.party.openingBalancePaise)}", 40f, y, bodyPaint)
        y += 22f
        canvas.drawText("बड़े जानवर (${summary.totalBigAnimals} नग, ${CurrencyUtils.formatGramsToKg(summary.totalBigWeightGrams)}): ${CurrencyUtils.formatIndianRupees(summary.totalBigAmountPaise)}", 40f, y, bodyPaint)
        y += 22f
        canvas.drawText("Veal माल (${CurrencyUtils.formatGramsToKg(summary.totalVealWeightGrams)}): ${CurrencyUtils.formatIndianRupees(summary.totalVealAmountPaise)}", 40f, y, bodyPaint)
        y += 22f
        canvas.drawText("कुल हिसाब रकम: ${CurrencyUtils.formatIndianRupees(summary.grandTotalPayableOrReceivablePaise)}", 40f, y, bodyPaint)
        y += 22f
        canvas.drawText("कुल भुगतान: ${CurrencyUtils.formatIndianRupees(summary.totalPaymentsPaise)}", 40f, y, bodyPaint)
        y += 26f
        canvas.drawText("वर्तमान बाकी रकम: ${CurrencyUtils.formatIndianRupees(summary.remainingBalancePaise)}", 40f, y, titlePaint)

        pdfDocument.finishPage(page)
        FileOutputStream(file).use { pdfDocument.writeTo(it) }
        pdfDocument.close()
        return file
    }

    fun printWebViewReport(context: Context, webView: WebView, jobName: String = "HAWELI_Hisab_Report") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = webView.createPrintDocumentAdapter(jobName)
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }
}
