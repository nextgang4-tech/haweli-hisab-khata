package com.haweli.hisab.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val HaweliDarkBlue = Color(0xFF0F172A)
val HaweliNavy = Color(0xFF1E293B)
val HaweliGreen = Color(0xFF059669)
val HaweliEmerald = Color(0xFF10B981)
val DenaRed = Color(0xFFDC2626)
val AanaGreen = Color(0xFF16A34A)
val SurfaceLight = Color(0xFFF8FAFC)

private val LightColorPalette = lightColorScheme(
    primary = HaweliDarkBlue,
    onPrimary = Color.White,
    secondary = HaweliGreen,
    onSecondary = Color.White,
    background = SurfaceLight,
    surface = Color.White,
    onBackground = HaweliDarkBlue,
    onSurface = HaweliDarkBlue
)

@Composable
fun HaweliTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorPalette,
        content = content
    )
}
