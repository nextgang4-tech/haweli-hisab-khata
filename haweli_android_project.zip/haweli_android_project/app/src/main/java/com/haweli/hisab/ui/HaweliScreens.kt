package com.haweli.hisab

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haweli.hisab.data.FirebaseConfigManager
import com.haweli.hisab.model.*
import com.haweli.hisab.ui.theme.*
import com.haweli.hisab.util.CurrencyUtils
import com.haweli.hisab.util.ReportExporter
import com.haweli.hisab.viewmodel.HaweliViewModel

@Composable
fun CityPartySectionView(
    ledgerType: LedgerType,
    cities: List<CityRecord>,
    parties: List<PartyRecord>,
    viewModel: HaweliViewModel,
    currentUser: String,
    onOpenPartyLedger: (PartyRecord) -> Unit
) {
    var selectedCityId by remember { mutableStateOf(cities.firstOrNull()?.id ?: "") }
    var newCityName by remember { mutableStateOf("") }
    var partyName by remember { mutableStateOf("") }
    var partyMobile by remember { mutableStateOf("") }
    var openingRupees by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            if (ledgerType == LedgerType.DENA) "देना – शहर के अनुसार हिसाब" else "आना – शहर और गाड़ी के अनुसार हिसाब",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )

        // Add City Row
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newCityName,
                onValueChange = { newCityName = it },
                label = { Text("नया शहर जोड़ें (जैसे बारामती)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Button(
                onClick = {
                    if (newCityName.isNotBlank()) {
                        viewModel.repository.saveCity(CityRecord(name = newCityName.trim()), currentUser)
                        newCityName = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = HaweliGreen)
            ) {
                Text("शहर सेव करें")
            }
        }

        // City Tabs
        ScrollableTabRow(selectedTabIndex = cities.indexOfFirst { it.id == selectedCityId }.coerceAtLeast(0)) {
            cities.forEach { city ->
                Tab(
                    selected = city.id == selectedCityId,
                    onClick = { selectedCityId = city.id },
                    text = { Text(city.name, fontWeight = FontWeight.Bold) }
                )
            }
        }

        // Add Party in Selected City
        val currentCity = cities.find { it.id == selectedCityId } ?: cities.firstOrNull()
        if (currentCity != null) {
            Card(shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${currentCity.name} में नई पार्टी जोड़ें", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = partyName,
                            onValueChange = { partyName = it },
                            label = { Text("पार्टी का नाम") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = partyMobile,
                            onValueChange = { partyMobile = it },
                            label = { Text("मोबाइल नंबर") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = openingRupees,
                            onValueChange = { openingRupees = it },
                            label = { Text("शुरुआती पुरानी बाकी (₹)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                if (partyName.isNotBlank()) {
                                    viewModel.repository.saveParty(
                                        PartyRecord(
                                            name = partyName.trim(),
                                            mobile = partyMobile.trim(),
                                            cityId = currentCity.id,
                                            cityName = currentCity.name,
                                            type = ledgerType.name,
                                            openingBalancePaise = CurrencyUtils.rupeesToPaise(openingRupees)
                                        ),
                                        currentUser
                                    )
                                    partyName = ""
                                    partyMobile = ""
                                    openingRupees = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkBlue)
                        ) {
                            Text("पार्टी जोड़ें")
                        }
                    }
                }
            }
        }

        // Party List for Selected City
        val cityParties = parties.filter { currentCity == null || it.cityId == currentCity.id }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(cityParties) { party ->
                val summary = viewModel.computePartySummary(party)
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenPartyLedger(party) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(party.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(party.cityName, color = HaweliGreen, fontWeight = FontWeight.SemiBold)
                        }
                        Text("कुल हिसाब: ${CurrencyUtils.formatIndianRupees(summary.grandTotalPayableOrReceivablePaise)} | भुगतान: ${CurrencyUtils.formatIndianRupees(summary.totalPaymentsPaise)}")
                        Text(
                            "वर्तमान बाकी: ${CurrencyUtils.formatIndianRupees(summary.remainingBalancePaise)}",
                            fontWeight = FontWeight.Bold,
                            color = if (ledgerType == LedgerType.DENA) DenaRed else AanaGreen
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PartyLedgerDetailView(
    party: PartyRecord,
    viewModel: HaweliViewModel,
    currentUser: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val bills by viewModel.repository.bills.collectAsState()
    val payments by viewModel.repository.payments.collectAsState()
    val summary = remember(party, bills, payments) { viewModel.computePartySummary(party) }

    var vehicleNo by remember { mutableStateOf("") }
    var bigCount by remember { mutableStateOf("") }
    var bigWeightKg by remember { mutableStateOf("") }
    var bigRateRs by remember { mutableStateOf("") }
    var vealWeightKg by remember { mutableStateOf("") }
    var vealRateRs by remember { mutableStateOf("") }
    var otherExpRs by remember { mutableStateOf("") }

    var payAmountRs by remember { mutableStateOf("") }
    var payMode by remember { mutableStateOf("नकद (Cash)") }
    var payNote by remember { mutableStateOf("") }

    val liveBigTotalPaise = CurrencyUtils.calculateWeightXRatePaise(
        CurrencyUtils.kgToGrams(bigWeightKg),
        CurrencyUtils.rupeesToPaise(bigRateRs)
    )
    val liveVealTotalPaise = CurrencyUtils.calculateWeightXRatePaise(
        CurrencyUtils.kgToGrams(vealWeightKg),
        CurrencyUtils.rupeesToPaise(vealRateRs)
    )
    val liveBillTotalPaise = liveBigTotalPaise + liveVealTotalPaise + CurrencyUtils.rupeesToPaise(otherExpRs)

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${party.name} (${party.cityName})", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                SummaryRow("शुरुआती पुरानी बाकी:", CurrencyUtils.formatIndianRupees(party.openingBalancePaise))
                SummaryRow("बड़े जानवरों की कुल रकम (${summary.totalBigAnimals} नग):", CurrencyUtils.formatIndianRupees(summary.totalBigAmountPaise))
                SummaryRow("Veal माल की कुल रकम:", CurrencyUtils.formatIndianRupees(summary.totalVealAmountPaise))
                SummaryRow("पार्टी का कुल हिसाब:", CurrencyUtils.formatIndianRupees(summary.grandTotalPayableOrReceivablePaise), bold = true)
                SummaryRow("कुल भुगतान:", CurrencyUtils.formatIndianRupees(summary.totalPaymentsPaise))
                SummaryRow(
                    "वर्तमान बाकी रकम:",
                    CurrencyUtils.formatIndianRupees(summary.remainingBalancePaise),
                    bold = true,
                    valueColor = if (party.type == LedgerType.DENA.name) DenaRed else AanaGreen
                )
                Button(
                    onClick = { ReportExporter.exportPartyLedgerPdf(context, summary) },
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliGreen)
                ) {
                    Text("PDF खाता स्टेटमेंट डाउनलोड करें")
                }
            }
        }

        // Add Bill Form (बड़े जानवर + Veal माल का हिसाब)
        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("नया माल / बिल जोड़ें (बड़े जानवर + Veal माल)", fontWeight = FontWeight.Bold)
                if (party.type == LedgerType.AANA.name) {
                    OutlinedTextField(
                        value = vehicleNo,
                        onValueChange = { vehicleNo = it },
                        label = { Text("गाड़ी नंबर (जैसे MH-12-AB-1234)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = bigCount, onValueChange = { bigCount = it }, label = { Text("बड़े जानवर संख्या") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = bigWeightKg, onValueChange = { bigWeightKg = it }, label = { Text("कुल वजन (KG)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = bigRateRs, onValueChange = { bigRateRs = it }, label = { Text("प्रति KG रेट (₹)") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Text("बड़े जानवर रकम: ${CurrencyUtils.formatIndianRupees(liveBigTotalPaise)}", fontWeight = FontWeight.SemiBold, color = HaweliDarkBlue)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = vealWeightKg, onValueChange = { vealWeightKg = it }, label = { Text("Veal वजन (KG)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = vealRateRs, onValueChange = { vealRateRs = it }, label = { Text("Veal रेट (₹)") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Text("Veal माल रकम: ${CurrencyUtils.formatIndianRupees(liveVealTotalPaise)}", fontWeight = FontWeight.SemiBold, color = HaweliDarkBlue)

                if (party.type == LedgerType.AANA.name) {
                    OutlinedTextField(value = otherExpRs, onValueChange = { otherExpRs = it }, label = { Text("अन्य खर्च / एडजस्टमेंट (₹)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }

                Text("कुल बिल रकम: ${CurrencyUtils.formatIndianRupees(liveBillTotalPaise)}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = HaweliGreen)

                Button(
                    onClick = {
                        if (liveBillTotalPaise > 0L) {
                            viewModel.repository.saveBill(
                                BillTransaction(
                                    partyId = party.id,
                                    partyName = party.name,
                                    cityId = party.cityId,
                                    cityName = party.cityName,
                                    type = party.type,
                                    vehicleNumber = vehicleNo.trim(),
                                    bigAnimalCount = bigCount.toIntOrNull() ?: 0,
                                    bigAnimalWeightGrams = CurrencyUtils.kgToGrams(bigWeightKg),
                                    bigAnimalRatePaise = CurrencyUtils.rupeesToPaise(bigRateRs),
                                    vealWeightGrams = CurrencyUtils.kgToGrams(vealWeightKg),
                                    vealRatePaise = CurrencyUtils.rupeesToPaise(vealRateRs),
                                    otherExpensePaise = CurrencyUtils.rupeesToPaise(otherExpRs)
                                ),
                                currentUser
                            )
                            vehicleNo = ""; bigCount = ""; bigWeightKg = ""; bigRateRs = ""; vealWeightKg = ""; vealRateRs = ""; otherExpRs = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkBlue)
                ) {
                    Text("माल बिल सेव करें")
                }
            }
        }

        // Add Payment Form
        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (party.type == LedgerType.DENA.name) "भुगतान जोड़ें (पैसे दिए)" else "प्राप्त भुगतान जोड़ें (पैसे आए)", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = payAmountRs, onValueChange = { payAmountRs = it }, label = { Text("रकम (₹)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = payMode, onValueChange = { payMode = it }, label = { Text("भुगतान का तरीका") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = payNote, onValueChange = { payNote = it }, label = { Text("नोट / विवरण") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(
                    onClick = {
                        val amt = CurrencyUtils.rupeesToPaise(payAmountRs)
                        if (amt > 0L) {
                            viewModel.repository.savePayment(
                                PaymentTransaction(
                                    partyId = party.id,
                                    partyName = party.name,
                                    cityId = party.cityId,
                                    cityName = party.cityName,
                                    type = party.type,
                                    amountPaise = amt,
                                    paymentMode = payMode.trim(),
                                    note = payNote.trim()
                                ),
                                currentUser
                            )
                            payAmountRs = ""; payNote = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = HaweliGreen)
                ) {
                    Text("भुगतान सेव करें")
                }
            }
        }
    }
}

@Composable
fun OfficeApsarBhaiView(
    transactions: List<OfficeApsarTransaction>,
    viewModel: HaweliViewModel,
    currentUser: String
) {
    val summary = remember(transactions) { viewModel.computeApsarBhaiSummary() }
    var direction by remember { mutableStateOf("GIVEN") }
    var personName by remember { mutableStateOf("") }
    var amountRs by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ऑफिस – APSAR BHAI डैशबोर्ड", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SummaryRow("1. कुल दिए हुए पैसे:", CurrencyUtils.formatIndianRupees(summary.totalGivenPaise), valueColor = DenaRed)
                SummaryRow("2. कुल लिए हुए पैसे:", CurrencyUtils.formatIndianRupees(summary.totalTakenPaise), valueColor = AanaGreen)
                SummaryRow(
                    "3. वर्तमान नेट बैलेंस (कुल दिए – कुल लिए):",
                    CurrencyUtils.formatIndianRupees(summary.netBalancePaise),
                    bold = true
                )
                if (summary.isExcessTaken) {
                    Text(
                        "नोट: लिए गए पैसे दिए गए पैसों से ${CurrencyUtils.formatIndianRupees(kotlin.math.abs(summary.netBalancePaise))} अधिक हैं।",
                        color = AanaGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { direction = "GIVEN" },
                colors = ButtonDefaults.buttonColors(containerColor = if (direction == "GIVEN") DenaRed else Color.Gray),
                modifier = Modifier.weight(1f)
            ) { Text("पैसे दिए (Given)") }
            Button(
                onClick = { direction = "TAKEN" },
                colors = ButtonDefaults.buttonColors(containerColor = if (direction == "TAKEN") AanaGreen else Color.Gray),
                modifier = Modifier.weight(1f)
            ) { Text("पैसे लिए (Taken)") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = personName, onValueChange = { personName = it }, label = { Text("व्यक्ति का नाम") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = amountRs, onValueChange = { amountRs = it }, label = { Text("रकम (₹)") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("कारण") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("नोट") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        Button(
            onClick = {
                val amt = CurrencyUtils.rupeesToPaise(amountRs)
                if (personName.isNotBlank() && amt > 0L) {
                    viewModel.repository.saveOfficeTransaction(
                        OfficeApsarTransaction(
                            direction = direction,
                            personName = personName.trim(),
                            amountPaise = amt,
                            reason = reason.trim(),
                            note = note.trim()
                        ),
                        currentUser
                    )
                    personName = ""; amountRs = ""; reason = ""; note = ""
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkBlue)
        ) {
            Text("APSAR BHAI एंट्री सेव करें")
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(transactions) { tx ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${tx.personName} (${if (tx.direction == "GIVEN") "पैसे दिए" else "पैसे लिए"})", fontWeight = FontWeight.Bold)
                            Text("तारीख: ${tx.date} | कारण: ${tx.reason}")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                CurrencyUtils.formatIndianRupees(tx.amountPaise),
                                fontWeight = FontWeight.Bold,
                                color = if (tx.direction == "GIVEN") DenaRed else AanaGreen
                            )
                            IconButton(onClick = { viewModel.repository.deleteOfficeTransaction(tx.id, currentUser) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DenaRed)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthlyReportView(viewModel: HaweliViewModel) {
    val context = LocalContext.current
    var fromDate by remember { mutableStateOf("01/11/2026") }
    var toDate by remember { mutableStateOf("30/11/2026") }
    val parties by viewModel.repository.parties.collectAsState()
    val bills by viewModel.repository.bills.collectAsState()
    val payments by viewModel.repository.payments.collectAsState()
    val office by viewModel.repository.officeTransactions.collectAsState()

    val report = remember(fromDate, toDate, parties, bills, payments, office) {
        viewModel.computeDateRangeReport(fromDate, toDate)
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("महीने का हिसाब (Date Range रिपोर्ट)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = fromDate, onValueChange = { fromDate = it }, label = { Text("शुरुआती तारीख (DD/MM/YYYY)") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = toDate, onValueChange = { toDate = it }, label = { Text("अंतिम तारीख (DD/MM/YYYY)") }, modifier = Modifier.weight(1f), singleLine = true)
        }

        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("माल का हिसाब (${report.fromDate} से ${report.toDate})", fontWeight = FontWeight.Bold, color = HaweliDarkBlue)
                SummaryRow("बड़े जानवर कटे/भेजे गए:", "${report.bigAnimalCount} नग")
                SummaryRow("बड़े जानवरों का कुल वजन:", CurrencyUtils.formatGramsToKg(report.bigAnimalWeightGrams))
                SummaryRow("बड़े जानवरों की कुल रकम:", CurrencyUtils.formatIndianRupees(report.bigAnimalTotalPaise))
                SummaryRow("Veal माल का कुल वजन:", CurrencyUtils.formatGramsToKg(report.vealWeightGrams))
                SummaryRow("Veal माल की कुल रकम:", CurrencyUtils.formatIndianRupees(report.vealTotalPaise))
                SummaryRow("दोनों का कुल वजन:", CurrencyUtils.formatGramsToKg(report.combinedWeightGrams), bold = true)
                SummaryRow("दोनों की कुल रकम:", CurrencyUtils.formatIndianRupees(report.combinedMaalPaise), bold = true)
            }
        }

        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("पैसे का हिसाब (पुराना बकाया अलग + अंत का बैलेंस)", fontWeight = FontWeight.Bold, color = HaweliDarkBlue)
                SummaryRow("अवधि से पहले का पुराना देना बकाया:", CurrencyUtils.formatIndianRupees(report.openingDenaBeforePeriodPaise))
                SummaryRow("इस अवधि में कुल देना बना:", CurrencyUtils.formatIndianRupees(report.periodDenaBillsPaise))
                SummaryRow("इस अवधि में कुल भुगतान दिया:", CurrencyUtils.formatIndianRupees(report.periodDenaPaymentsPaise))
                SummaryRow("महीने के अंत में कुल देना बाकी:", CurrencyUtils.formatIndianRupees(report.closingDenaAtEndPaise), bold = true, valueColor = DenaRed)
                Divider()
                SummaryRow("अवधि से पहले का पुराना आना बकाया:", CurrencyUtils.formatIndianRupees(report.openingAanaBeforePeriodPaise))
                SummaryRow("इस अवधि में कुल आना बना:", CurrencyUtils.formatIndianRupees(report.periodAanaBillsPaise))
                SummaryRow("इस अवधि में कुल भुगतान प्राप्त हुआ:", CurrencyUtils.formatIndianRupees(report.periodAanaPaymentsPaise))
                SummaryRow("महीने के अंत में कुल आना बाकी:", CurrencyUtils.formatIndianRupees(report.closingAanaAtEndPaise), bold = true, valueColor = AanaGreen)
                Divider()
                SummaryRow("APSAR BHAI इस अवधि में दिए:", CurrencyUtils.formatIndianRupees(report.apsarGivenInPeriodPaise))
                SummaryRow("APSAR BHAI इस अवधि में लिए:", CurrencyUtils.formatIndianRupees(report.apsarTakenInPeriodPaise))
            }
        }

        Button(
            onClick = {
                val summaries = parties.map { viewModel.computePartySummary(it) }
                ReportExporter.exportMonthlyReportCsv(context, report, summaries)
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = HaweliGreen)
        ) {
            Text("महीने की रिपोर्ट Excel (CSV) में डाउनलोड करें")
        }
    }
}

@Composable
fun AllPartiesManagementView(
    cities: List<CityRecord>,
    parties: List<PartyRecord>,
    viewModel: HaweliViewModel,
    onOpenPartyLedger: (PartyRecord) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCityFilter by remember { mutableStateOf("ALL") }

    val filtered = parties.filter { p ->
        (selectedCityFilter == "ALL" || p.cityId == selectedCityFilter) &&
        (searchQuery.isBlank() || p.name.contains(searchQuery, ignoreCase = true) || p.cityName.contains(searchQuery, ignoreCase = true))
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("सभी पार्टियां (All Party Management)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("पार्टी या शहर का नाम खोजें...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(filtered) { party ->
                val summary = viewModel.computePartySummary(party)
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenPartyLedger(party) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${party.name} (${party.cityName})", fontWeight = FontWeight.Bold)
                            Text(
                                if (party.type == "DENA") "देना" else "आना",
                                color = if (party.type == "DENA") DenaRed else AanaGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text("कुल रकम: ${CurrencyUtils.formatIndianRupees(summary.grandTotalPayableOrReceivablePaise)} | भुगतान: ${CurrencyUtils.formatIndianRupees(summary.totalPaymentsPaise)}")
                        Text("बाकी रकम: ${CurrencyUtils.formatIndianRupees(summary.remainingBalancePaise)}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AuditAndReportsView(
    auditLogs: List<AuditLogEntry>,
    parties: List<PartyRecord>,
    viewModel: HaweliViewModel,
    onOpenPartyLedger: (PartyRecord) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("पेमेंट रिमाइंडर और ऑडिट लॉग (Audit Log)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(auditLogs) { log ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(log.summaryHindi, fontWeight = FontWeight.SemiBold)
                        Text("यूज़र: ${log.performedBy} | तारीख: ${log.dateFormatted} | डिवाइस: ${log.deviceName}", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsAndAdminView(
    viewModel: HaweliViewModel,
    isAdmin: Boolean
) {
    val context = LocalContext.current
    var config by remember { mutableStateOf(FirebaseConfigManager.getConfig(context)) }
    var projectId by remember { mutableStateOf(config.projectId) }
    var apiKey by remember { mutableStateOf(config.apiKey) }
    var appId by remember { mutableStateOf(config.applicationId) }
    var storageBucket by remember { mutableStateOf(config.storageBucket) }

    var adminUser by remember { mutableStateOf("") }
    var adminPass by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Admin Login System", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (!isAdmin) {
                    OutlinedTextField(value = adminUser, onValueChange = { adminUser = it }, label = { Text("Admin Username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = adminPass, onValueChange = { adminPass = it }, label = { Text("Admin Password") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(
                        onClick = {
                            val ok = viewModel.loginAsAdmin(adminUser, adminPass)
                            statusMessage = if (ok) "Admin सफलतापूर्वक लॉगिन हो गया!" else "गलत Username या Password!"
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = HaweliDarkBlue)
                    ) {
                        Text("Login Button")
                    }
                } else {
                    Text("Admin लॉगिन सक्रिय है (सभी अधिकार उपलब्ध हैं)", color = HaweliGreen, fontWeight = FontWeight.Bold)
                    Button(onClick = { viewModel.logoutAdmin() }, colors = ButtonDefaults.buttonColors(containerColor = DenaRed)) {
                        Text("Admin लॉगआउट करें")
                    }
                }
            }
        }

        Card(shape = RoundedCornerShape(14.dp)) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Firebase Configuration & Lock System", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (config.isLocked && !isAdmin) {
                    Text("सुरक्षा लॉक सक्रिय: Firebase Configuration सफलतापूर्वक लॉक है। सामान्य उपयोगकर्ता इसे देख या बदल नहीं सकते। बदलने के लिए ऊपर Admin Login करें।", color = HaweliGreen, fontWeight = FontWeight.SemiBold)
                } else {
                    OutlinedTextField(value = projectId, onValueChange = { projectId = it }, label = { Text("Firebase Project ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Firebase API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = appId, onValueChange = { appId = it }, label = { Text("Firebase App ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = storageBucket, onValueChange = { storageBucket = it }, label = { Text("Storage Bucket (वैकल्पिक)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(
                        onClick = {
                            val ok = FirebaseConfigManager.saveAndLockConfig(context, projectId, apiKey, appId, storageBucket, lock = true)
                            config = FirebaseConfigManager.getConfig(context)
                            viewModel.repository.attachFirestoreRealtimeListeners()
                            statusMessage = if (ok) "Firebase Connect सफल और Configuration Lock कर दिया गया!" else "Configuration सेव और Lock हो गया।"
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = HaweliGreen)
                    ) {
                        Text("Firebase Connect & Lock Configuration")
                    }
                }
                if (statusMessage.isNotBlank()) {
                    Text(statusMessage, fontWeight = FontWeight.Bold, color = HaweliDarkBlue)
                }
            }
        }
    }
}
