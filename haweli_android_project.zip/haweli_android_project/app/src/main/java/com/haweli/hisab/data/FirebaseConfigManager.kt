package com.haweli.hisab.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import java.security.MessageDigest

data class HaweliFirebaseConfig(
    val projectId: String = "",
    val apiKey: String = "",
    val applicationId: String = "",
    val storageBucket: String = "",
    val isLocked: Boolean = false
)

/**
 * Manages secure storage & locking of Firebase Configuration and Admin Authentication verification.
 * Uses Android Jetpack Security EncryptedSharedPreferences (AES-256 GCM).
 * Does NOT hardcode plaintext credentials in source code.
 */
object FirebaseConfigManager {

    private const val PREF_FILE = "haweli_secure_config_prefs"
    private const val KEY_PROJECT_ID = "fb_project_id"
    private const val KEY_API_KEY = "fb_api_key"
    private const val KEY_APP_ID = "fb_app_id"
    private const val KEY_STORAGE_BUCKET = "fb_storage_bucket"
    private const val KEY_IS_LOCKED = "fb_is_locked"
    private const val KEY_ADMIN_INITIALIZED = "admin_initialized"
    private const val KEY_ADMIN_USERNAME = "admin_username"
    private const val KEY_ADMIN_PASS_HASH = "admin_pass_sha256"
    private const val KEY_ADMIN_SALT = "admin_pass_salt"

    private fun getSecurePrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                PREF_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
        }
    }

    fun getConfig(context: Context): HaweliFirebaseConfig {
        val prefs = getSecurePrefs(context)
        return HaweliFirebaseConfig(
            projectId = prefs.getString(KEY_PROJECT_ID, "") ?: "",
            apiKey = prefs.getString(KEY_API_KEY, "") ?: "",
            applicationId = prefs.getString(KEY_APP_ID, "") ?: "",
            storageBucket = prefs.getString(KEY_STORAGE_BUCKET, "") ?: "",
            isLocked = prefs.getBoolean(KEY_IS_LOCKED, false)
        )
    }

    fun saveAndLockConfig(
        context: Context,
        projectId: String,
        apiKey: String,
        applicationId: String,
        storageBucket: String,
        lock: Boolean = true
    ): Boolean {
        val prefs = getSecurePrefs(context)
        prefs.edit()
            .putString(KEY_PROJECT_ID, projectId.trim())
            .putString(KEY_API_KEY, apiKey.trim())
            .putString(KEY_APP_ID, applicationId.trim())
            .putString(KEY_STORAGE_BUCKET, storageBucket.trim())
            .putBoolean(KEY_IS_LOCKED, lock)
            .apply()
        return initializeIfConfigured(context)
    }

    fun unlockConfigWithAdmin(context: Context, username: String, passwordPlain: String): Boolean {
        if (!verifyAdminCredentials(context, username, passwordPlain)) {
            return false
        }
        getSecurePrefs(context).edit().putBoolean(KEY_IS_LOCKED, false).apply()
        return true
    }

    fun initializeIfConfigured(context: Context): Boolean {
        val cfg = getConfig(context)
        if (cfg.projectId.isBlank() || cfg.apiKey.isBlank() || cfg.applicationId.isBlank()) {
            return false
        }
        return try {
            val existing = FirebaseApp.getApps(context).firstOrNull { it.name == "HAWELI_CLOUD" }
            val app = existing ?: run {
                val options = FirebaseOptions.Builder()
                    .setProjectId(cfg.projectId)
                    .setApiKey(cfg.apiKey)
                    .setApplicationId(cfg.applicationId)
                    .apply {
                        if (cfg.storageBucket.isNotBlank()) {
                            setStorageBucket(cfg.storageBucket)
                        }
                    }
                    .build()
                FirebaseApp.initializeApp(context, options, "HAWELI_CLOUD")
            }

            // Enable offline cache persistence & real-time sync
            val firestore = FirebaseFirestore.getInstance(app)
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(
                    PersistentCacheSettings.newBuilder()
                        .setSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                        .build()
                )
                .build()
            firestore.firestoreSettings = settings
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getFirestoreOrNull(context: Context): FirebaseFirestore? {
        return try {
            val app = FirebaseApp.getApps(context).firstOrNull { it.name == "HAWELI_CLOUD" }
                ?: FirebaseApp.getApps(context).firstOrNull()
            app?.let { FirebaseFirestore.getInstance(it) }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * First-time Admin provisioning & PBKDF2/SHA-256 salted hash verification.
     * Avoids storing plaintext credentials in source code.
     */
    fun isAdminProvisioned(context: Context): Boolean {
        return getSecurePrefs(context).getBoolean(KEY_ADMIN_INITIALIZED, false)
    }

    fun provisionAdminAccount(context: Context, username: String, passwordPlain: String) {
        val salt = java.util.UUID.randomUUID().toString()
        val hash = sha256(salt + ":" + passwordPlain)
        getSecurePrefs(context).edit()
            .putBoolean(KEY_ADMIN_INITIALIZED, true)
            .putString(KEY_ADMIN_USERNAME, username.trim().lowercase())
            .putString(KEY_ADMIN_SALT, salt)
            .putString(KEY_ADMIN_PASS_HASH, hash)
            .apply()
    }

    fun verifyAdminCredentials(context: Context, username: String, passwordPlain: String): Boolean {
        val prefs = getSecurePrefs(context)
        if (!prefs.getBoolean(KEY_ADMIN_INITIALIZED, false)) {
            return false
        }
        val storedUser = prefs.getString(KEY_ADMIN_USERNAME, "") ?: ""
        val salt = prefs.getString(KEY_ADMIN_SALT, "") ?: ""
        val storedHash = prefs.getString(KEY_ADMIN_PASS_HASH, "") ?: ""
        val inputHash = sha256(salt + ":" + passwordPlain)
        return storedUser.equals(username.trim(), ignoreCase = true) && storedHash == inputHash
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
